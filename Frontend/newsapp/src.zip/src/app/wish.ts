export class Wish{
    Title : string |undefined;
    Author : string |undefined;
    Description : string |undefined;
    Url : string |undefined;
    UrlToImage : string |undefined;
    UserName : string |undefined;
}
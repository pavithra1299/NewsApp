import { Injectable } from '@angular/core';
import { LoginService } from './login.service';
import {   Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService {

  constructor() { }

  
  
}

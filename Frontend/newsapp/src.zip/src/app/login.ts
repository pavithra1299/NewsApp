export class Login{
    UserId : string | undefined;
    Password : string | undefined;
}
export class User{
 
    UserName : string | undefined;
    FirstName : string | undefined;
    LastName : string | undefined;
    Email : string |undefined;
    Mobile : string | undefined;
    CreatePassword : string | undefined;
    ConfirmPassword : string | undefined;
}